-- Solo lectura. Ejecutar en la base de desarrollo de SGI Comando.
-- Debe aparecer exactamente una fila para el empleado activo de Galvarino.
WITH origen AS (
  SELECT username, instance_country_id, roles, active
  FROM app_user
  WHERE username = 'agente'
), galvarino AS (
  SELECT c.id, c.instance_country_id, c.code, c.name
  FROM company c
  JOIN origen o ON o.instance_country_id = c.instance_country_id
  WHERE lower(btrim(c.name)) = 'galvarino' AND c.status = 'ACTIVE'
), persona AS (
  SELECT e.employee_id, e.persona_id, e.full_name, e.role_code,
         e.employment_status, e.instance_country_id, e.company_id
  FROM employee_operational_snapshot e
  JOIN galvarino c ON c.id = e.company_id AND c.instance_country_id = e.instance_country_id
  WHERE lower(translate(regexp_replace(btrim(e.full_name), '\s+', ' ', 'g'),
        'ÁÉÍÓÚÜÑáéíóúüñ', 'AEIOUUNaeiouun')) = 'adan rufino bamonde palma'
)
SELECT p.employee_id, p.persona_id, p.full_name, p.role_code, p.employment_status,
       c.code AS company_code, c.name AS company_name,
       EXISTS (
         SELECT 1 FROM company_membership m
         WHERE m.instance_country_id = p.instance_country_id
           AND m.employee_id = p.employee_id AND m.company_id = c.id
           AND m.membership_type = 'PRIMARY' AND m.ends_at IS NULL
           AND m.starts_at <= now()
       ) AS primary_membership_active,
       (SELECT string_agg(b.username, ', ' ORDER BY b.username)
        FROM operator_employee_binding b
        WHERE b.instance_country_id = p.instance_country_id
          AND b.employee_id = p.employee_id AND b.active) AS current_operator_logins,
       (SELECT string_agg(u.username, ', ' ORDER BY u.username)
        FROM app_user u
        WHERE u.instance_country_id = p.instance_country_id
          AND lower(translate(regexp_replace(btrim(u.display_name), '\s+', ' ', 'g'),
              'ÁÉÍÓÚÜÑáéíóúüñ', 'AEIOUUNaeiouun')) =
              lower(translate(regexp_replace(btrim(p.full_name), '\s+', ' ', 'g'),
              'ÁÉÍÓÚÜÑáéíóúüñ', 'AEIOUUNaeiouun'))
       ) AS existing_accounts_with_same_name
FROM persona p
JOIN galvarino c ON c.id = p.company_id
ORDER BY p.full_name;

-- Comprueba que la cuenta UAT de origen tiene el rol y el alcance requeridos.
SELECT u.username, u.roles, u.active, c.code AS scope_company_code, c.name AS scope_company_name
FROM app_user u
LEFT JOIN user_operational_scope s
  ON s.instance_country_id = u.instance_country_id AND s.username = u.username
  AND s.scope_type = 'COMPANY'
LEFT JOIN company c ON c.id = s.scope_id AND c.instance_country_id = u.instance_country_id
WHERE u.username = 'agente';
