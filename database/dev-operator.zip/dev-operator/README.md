# Habilitar a Adan Bamonde en SGI Operador (desarrollo)

Estos scripts son manuales para PostgreSQL. No son migraciones Flyway y no se ejecutan al iniciar la aplicación.

1. Ejecutar `01_verificar_adan_bamonde.sql` en la base del servidor de desarrollo. La primera consulta debe devolver **exactamente una fila**: Adan Rufino Bamonde Palma, empleado activo y miembro primario vigente de Galvarino. La segunda debe mostrar `agente` activo, con rol `AGENTE_SEGURIDAD` y alcance de Galvarino.
2. Revisar el `username` propuesto (`adan.bamonde`) en la primera sección de `02_habilitar_adan_bamonde.sql`. Si Adan ya tiene una cuenta con otro nombre de acceso, escribir allí ese nombre antes de ejecutar. Ejecutar el script completo en una sola sesión; termina con `COMMIT` y muestra una fila de verificación sin exponer contraseñas.

Ejemplo con `psql` desde una máquina con acceso a la base de desarrollo (sustituir host, usuario y base):

```sh
psql -X -v ON_ERROR_STOP=1 -h HOST -U USUARIO -d BASE -f database/dev-operator/01_verificar_adan_bamonde.sql
psql -X -v ON_ERROR_STOP=1 -h HOST -U USUARIO -d BASE -f database/dev-operator/02_habilitar_adan_bamonde.sql
```

Si `adan.bamonde` ya existe con el rol correcto, el script conserva su contraseña. Si crea una cuenta nueva, copia **solo en desarrollo** el hash de la credencial UAT de `agente`; no crea ni modifica la ficha del empleado. El alcance queda limitado a Galvarino. El script aborta ante identidad ambigua, membresía ausente, otro rol, alcance ajeno o vínculo previo con otro empleado.

El backend debe tener `SGI_OPERATOR_RELIEF_UAT_ENABLED=true` para habilitar las rutas de Operador. El acceso puede funcionar aunque la pantalla de turnos esté vacía: las asignaciones vigentes del empleado se publican por separado; estos scripts no crean turnos ni copian asignaciones de `agente`.
